from .models import register, make
from . import edsr, rdn, rcan
from . import mlp
from . import liif
from . import misc
